public interface Seguravel {

	public double calcularValorApolice();
	public String obterDescricao();

}