
public class Cachorro {

	String nome;
	String raca;
	char sexo;
	int idade;
	
}
