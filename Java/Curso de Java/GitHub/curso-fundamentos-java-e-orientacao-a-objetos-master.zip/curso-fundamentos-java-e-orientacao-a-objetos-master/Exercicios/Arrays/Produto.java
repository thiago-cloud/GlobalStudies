class Produto {
	
	String descricao;
	int quantidade;
	
	void descrever() {
		System.out.println(descricao + " - " + quantidade + " itens");
	}
	
}