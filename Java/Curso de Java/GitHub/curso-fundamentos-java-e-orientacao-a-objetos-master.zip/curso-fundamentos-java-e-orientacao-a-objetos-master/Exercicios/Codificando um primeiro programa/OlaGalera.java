public class OlaGalera {
	
	public static void main(String[] args) {
		System.out.println("Ola galera do curso de Java.");
	}
	
}