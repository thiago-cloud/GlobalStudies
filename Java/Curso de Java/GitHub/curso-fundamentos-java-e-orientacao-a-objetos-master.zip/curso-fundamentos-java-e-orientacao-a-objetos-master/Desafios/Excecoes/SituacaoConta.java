package com.algaworks.cursojava.financeiro.modelo;

public enum SituacaoConta {
	
	PENDENTE,
	PAGA,
	CANCELADA
	
}