package com.algaworks.cursojava.financeiro.modelo;

public class Fornecedor extends Pessoa {

}