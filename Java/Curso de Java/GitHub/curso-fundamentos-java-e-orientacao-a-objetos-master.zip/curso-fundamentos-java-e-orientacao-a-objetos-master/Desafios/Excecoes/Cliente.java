package com.algaworks.cursojava.financeiro.modelo;

public class Cliente extends Pessoa {
	
}