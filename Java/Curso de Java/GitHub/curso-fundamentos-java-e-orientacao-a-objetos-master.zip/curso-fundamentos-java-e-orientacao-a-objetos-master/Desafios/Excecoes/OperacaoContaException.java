package com.algaworks.cursojava.financeiro;

public class OperacaoContaException extends Exception {
	
	public OperacaoContaException(String msg) {
		super(msg);
	}
	
}