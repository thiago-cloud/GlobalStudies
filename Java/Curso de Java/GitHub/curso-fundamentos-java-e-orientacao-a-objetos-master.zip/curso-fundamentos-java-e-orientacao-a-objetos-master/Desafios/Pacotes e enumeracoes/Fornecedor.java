package com.algaworks.cursojava.financeiro.modelo;

public class Fornecedor {

	public String nome;

	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

}