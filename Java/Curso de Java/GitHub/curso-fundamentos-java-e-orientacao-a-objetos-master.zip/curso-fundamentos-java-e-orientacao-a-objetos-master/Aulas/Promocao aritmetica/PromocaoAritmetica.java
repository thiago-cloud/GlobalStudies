public class PromocaoAritmetica {

	public static void main(String[] args) {
		int x = 3;
		int y = 2;
		float z = x / (float) y;
		System.out.println(z);
	}

}