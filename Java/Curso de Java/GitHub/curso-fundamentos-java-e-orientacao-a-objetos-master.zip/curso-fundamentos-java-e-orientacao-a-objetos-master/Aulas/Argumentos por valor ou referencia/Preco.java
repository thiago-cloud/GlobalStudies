
public class Preco {

	double valorCustos;
	double valorImpostos;
	double valorLucro;
	double precoVenda;
	
}
