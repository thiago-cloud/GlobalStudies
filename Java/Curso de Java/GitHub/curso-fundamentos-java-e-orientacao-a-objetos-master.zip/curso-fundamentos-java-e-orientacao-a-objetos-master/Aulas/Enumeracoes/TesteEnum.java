package com.algaworks.curso.fjoo.enums;

public class TesteEnum {

	public static void main(String[] args) {
		Carta quatroPaus = new Carta(4, Naipe.PAUS);
		
		quatroPaus.imprimirCarta();
	}
	
}
