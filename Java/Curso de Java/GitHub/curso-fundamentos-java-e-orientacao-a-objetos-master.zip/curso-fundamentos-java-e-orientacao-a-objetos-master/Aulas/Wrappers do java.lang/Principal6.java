
public class Principal6 {

	public static void main(String[] args) {
		int x = 10;
		Integer i = new Integer(10);
		byte b = i.byteValue();
	
	}
	
}
