public class OiMundo {

	public static void main(String[] args) {
		System.out.println("Oi \nMundo");
	}

}