public class ConversaoTipoPrimitivo {

	public static void main(String[] args) {
		double largura = 100.37;
		
		int tamanho = (int) largura;
		
		System.out.println(tamanho);
	}


}