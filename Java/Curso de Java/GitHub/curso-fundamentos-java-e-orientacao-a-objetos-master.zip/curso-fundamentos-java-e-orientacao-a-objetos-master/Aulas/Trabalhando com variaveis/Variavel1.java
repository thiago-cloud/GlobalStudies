public class Variavel1 {

	public static void main(String[] args) {
		int quantidade; // Declarando variavel inteiro
		quantidade = 10; // atribuindo o valor 10
		
		System.out.println(quantidade);
		
		quantidade = 15;
		
		System.out.println(quantidade);		
	}

}