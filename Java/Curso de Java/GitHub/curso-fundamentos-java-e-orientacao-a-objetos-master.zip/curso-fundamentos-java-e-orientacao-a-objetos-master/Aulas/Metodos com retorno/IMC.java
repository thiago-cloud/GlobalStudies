
public class IMC {

	double indice;
	boolean abaixoDoPesoIdeal;
	boolean pesoIdeal;
	boolean obeso;
	String grauObesidade;
	
}
