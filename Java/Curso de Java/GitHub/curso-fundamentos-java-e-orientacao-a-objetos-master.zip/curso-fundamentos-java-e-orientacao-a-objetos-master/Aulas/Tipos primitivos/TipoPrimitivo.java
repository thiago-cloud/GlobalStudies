public class TipoPrimitivo {

	public static void main(String[] args) {
		double precoProduto = 9.43;
		
		boolean alunoMatriculado = true;
		boolean clienteBloqueado = false;
		
		char turmaAluno1 = 'A';
		char tipoCliente = '2';
		char simbolo = '@';
		
		long populacaoUberlandia = 650000;
		System.out.println(populacaoUberlandia);
		
		long populacaoMundial = 7000000000L;
		System.out.println(populacaoMundial);
		
		float saldoConta = 1030.43F;
		System.out.println(saldoConta);
	}
}