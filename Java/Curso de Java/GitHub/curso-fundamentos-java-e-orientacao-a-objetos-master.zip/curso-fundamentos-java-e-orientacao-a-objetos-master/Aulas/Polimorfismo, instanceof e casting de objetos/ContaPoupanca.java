package com.algaworks.curso.fjoo.polimorfismo;

public class ContaPoupanca extends Conta {

	private double rendimentos = 30;
	
	public double getRendimentos() {
		return rendimentos;
	}
	
}
