package com.algaworks.curso.fjoo.polimorfismo;

public class Conta {

	protected double saldo;
	
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
}
