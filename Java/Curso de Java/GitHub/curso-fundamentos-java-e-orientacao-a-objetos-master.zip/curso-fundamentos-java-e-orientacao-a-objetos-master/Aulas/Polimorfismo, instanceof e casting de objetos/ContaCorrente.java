package com.algaworks.curso.fjoo.polimorfismo;

public class ContaCorrente extends Conta {

	private double limite = 1000;
	
	public double getLimite() {
		return limite;
	}
	
}
