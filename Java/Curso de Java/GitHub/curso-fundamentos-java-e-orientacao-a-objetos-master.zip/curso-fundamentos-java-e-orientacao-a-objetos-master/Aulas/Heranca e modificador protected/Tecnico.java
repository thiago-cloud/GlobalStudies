package com.algaworks.curso.fjoo.heranca;

public class Tecnico extends Pessoa {

}
