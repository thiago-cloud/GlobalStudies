
public class Carro {

	String fabricante = "Sem fabricante";
	String modelo;
	String cor;
	int anoDeFabricacao = 2011;
	boolean biCombustivel = true;
	
	Proprietario dono = new Proprietario();

}
