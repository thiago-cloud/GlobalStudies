package com.algaworks.curso.fjoo.interfaces;

public interface Imprimivel {

	public void imprimir();
	
}
