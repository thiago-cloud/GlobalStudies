package com.algaworks.curso.fjoo.interfaces;

public interface EnviavelPorEmail {

	public void enviar(String email);
	
}
