public class TrabalhandoComStrings {

	public static void main(String[] args) {
		String nome = "Maria";
		int idade = 30;
		
		System.out.println(nome + " tem " + idade + " anos ");
		
	}

}