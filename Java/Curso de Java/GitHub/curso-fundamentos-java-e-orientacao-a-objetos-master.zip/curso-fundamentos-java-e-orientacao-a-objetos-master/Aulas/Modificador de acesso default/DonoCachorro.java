package com.algaworks.curso.fjoo.treinador;

import com.algaworks.curso.fjoo.animal.Cachorro;

public class DonoCachorro {

	void ensinarCachorroSentar(Cachorro cachorro) {
		cachorro.sentar();
	}
	
}
